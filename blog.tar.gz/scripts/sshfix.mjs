import { Client } from 'ssh2';
const c = new Client();
c.on('ready', () => {
  const r = (cmd) => new Promise((ok, no) => {
    c.exec(cmd, (e, s) => { if(e) return no(e); let o=''; s.on('data', d => { o+=d; process.stdout.write(d); }); s.stderr.on('data', d => { process.stderr.write(d); }); s.on('close', x => x ? no(new Error('E'+x)) : ok(o)); });
  });
  (async () => {
    try {
      console.log('#1 kill stuck nginx');
      await r('pkill nginx 2>/dev/null || true; echo ok');

      console.log('#2 check port 3000');
      await r('curl -sI --max-time 3 http://localhost:3000 2>&1 | head -3 || echo DOWN');

      console.log('#3 PM2 status');
      await r('pm2 list 2>&1 || echo NO_PM2');

      console.log('#4 rebuild and start');
      await r('cd /root/blog && npm run build 2>&1');
      await r('cd /root/blog && pm2 delete blog 2>/dev/null || true');
      await r('cd /root/blog && pm2 start ecosystem.config.js 2>&1');
      await r('pm2 save');

      console.log('#5 nginx config');
      await r('cp /root/blog/nginx.conf /etc/nginx/sites-available/blog');
      await r('ln -sf /etc/nginx/sites-available/blog /etc/nginx/sites-enabled/');
      await r('rm -f /etc/nginx/sites-enabled/default');
      await r('nginx -t 2>&1');
      await r('systemctl start nginx 2>/dev/null || nginx 2>&1');

      console.log('#6 verify');
      await r('sleep 2');
      await r('curl -sI --max-time 3 http://localhost | head -3');
      await r('pm2 list');
      const t = await r('curl -s --max-time 3 http://localhost | grep .title. || echo NO_TITLE');
      console.log('Title: ' + t.trim());

    } catch(e) { console.error('ERR:', e.message); }
    c.end();
    process.exit(0);
  })();
});
c.connect({ host: '115.190.136.177', port: 22, username: 'root', password: '[Lty060224]' });
