import { Client } from 'ssh2';
const c = new Client();
c.on('ready', () => {
  const r = (cmd) => new Promise((ok, no) => {
    c.exec(cmd, (e, s) => { if(e) return no(e); let o=''; s.on('data', d => { o+=d; process.stdout.write(d); }); s.stderr.on('data', d => { process.stderr.write(d); }); s.on('close', x => x ? no(new Error('E'+x)) : ok(o)); });
  });
  (async () => {
    try {
      console.log('1. Kill old stuff');
      await r('pkill -9 nginx 2>/dev/null || true');
      await r('pm2 delete blog 2>/dev/null || true');

      console.log('2. Pull latest code');
      await r('cd /root/blog && git fetch https://github.com/AAAxianyu/blog.git main && git reset --hard FETCH_HEAD');

      console.log('3. Install deps');
      await r('cd /root/blog && npm install 2>&1 | tail -3');

      console.log('4. Build');
      await r('cd /root/blog && NODE_OPTIONS=--max-old-space-size=512 npm run build 2>&1');

      console.log('5. Start PM2');
      await r('cd /root/blog && mkdir -p logs');
      await r('cd /root/blog && pm2 delete blog 2>/dev/null || true');
      await r('cd /root/blog && pm2 start ecosystem.config.js');
      await r('pm2 save');

      console.log('6. Nginx');
      await r('cp /root/blog/nginx.conf /etc/nginx/sites-available/blog');
      await r('ln -sf /etc/nginx/sites-available/blog /etc/nginx/sites-enabled/');
      await r('rm -f /etc/nginx/sites-enabled/default');
      await r('nginx -t 2>&1');
      await r('pkill nginx 2>/dev/null || true; sleep 1; nginx 2>&1 || (apt-get install -y nginx && nginx -t && nginx)');

      console.log('7. Verify');
      await r('sleep 2');
      await r('pm2 list');
      const t = await r('curl -s --max-time 5 http://localhost | grep -o .{3}title.{3}.[^<]*.{8}/title. || echo NO_TITLE');
      console.log('Title: ' + t.trim());
      await r('curl -sI --max-time 5 http://localhost | head -3');
      const t2 = await r('curl -s --max-time 5 http://localhost:3000 | grep -o .{3}title.{3}.[^<]*.{8}/title. || echo NO_TITLE');
      console.log('Port3000: ' + t2.trim());
      console.log('DONE');
    } catch(e) { console.error('ERR:', e.message); }
    c.end(); process.exit(0);
  })();
});
c.setTimeout(30000);
c.connect({ host: '115.190.136.177', port: 22, username: 'root', password: '[Lty060224]', readyTimeout: 30000 });
